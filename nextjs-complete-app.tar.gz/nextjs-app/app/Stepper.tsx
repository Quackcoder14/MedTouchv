"use client";

export default function Stepper({ step }: { step: number }) {
  const steps = ["Vitals", "Symptoms", "History", "Review"];

  return (
    <div className="flex justify-between items-center relative pb-4">
      {/* Progress Line */}
      <div className="absolute top-4 left-0 w-full h-1 bg-gray-200 -z-10">
        <div
          className="h-full bg-blue-600 transition-all duration-500"
          style={{ width: `${((step - 1) / (steps.length - 1)) * 100}%` }}
        />
      </div>

      {/* Steps */}
      {steps.map((label, index) => {
        const stepNumber = index + 1;
        const isActive = step === stepNumber;
        const isCompleted = step > stepNumber;

        return (
          <div
            key={index}
            className="flex flex-col items-center flex-1 relative"
          >
            {/* Circle */}
            <div
              className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-all duration-300 ${
                isActive
                  ? "bg-blue-600 text-white scale-110 shadow-lg"
                  : isCompleted
                  ? "bg-blue-600 text-white"
                  : "bg-gray-200 text-gray-500"
              }`}
            >
              {isCompleted ? "✓" : stepNumber}
            </div>

            {/* Label */}
            <div
              className={`mt-2 text-sm font-medium transition-all duration-300 ${
                isActive
                  ? "text-blue-600 font-bold scale-105"
                  : "text-gray-500"
              }`}
            >
              {label}
            </div>
          </div>
        );
      })}
    </div>
  );
}
