"use client";

import { useState } from "react";
import StepVitals from "./StepVitals";
import StepSymptoms from "./StepSymptoms";
import StepHistory from "./StepHistory";
import StepReview from "./StepReview";
import Stepper from "./Stepper";

export default function PatientPage() {
  const [step, setStep] = useState(1);

  const [formData, setFormData] = useState({
    age: 45,
    gender: "Male",
    heartRate: 80,
    temperature: 36.8,
    systolic: 120,
    diastolic: 80,
    symptoms: [] as string[],
    conditions: "No History",
  });

  const next = () => setStep((prev) => prev + 1);
  const prev = () => setStep((prev) => prev - 1);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center px-6 py-16">
      <div className="w-full max-w-5xl bg-white rounded-2xl shadow-xl border border-gray-200 p-8 md:p-12">

        <div className="mb-8">
          <h1 className="text-3xl font-bold text-blue-700 mb-2">
            🏥 MedTouch.ai
          </h1>
          <p className="text-gray-600">Smart Emergency Triage Dashboard</p>
        </div>

        <div className="mb-8 border-b border-gray-200">
          <Stepper step={step} />
        </div>

        <div className="mt-8">
          {step === 1 && (
            <StepVitals formData={formData} setFormData={setFormData} nextStep={next} />
          )}

          {step === 2 && (
            <StepSymptoms
              formData={formData}
              setFormData={setFormData}
              next={next}
              prev={prev}
            />
          )}

          {step === 3 && (
            <StepHistory
              formData={formData}
              setFormData={setFormData}
              next={next}
              prev={prev}
            />
          )}

          {step === 4 && (
            <StepReview formData={formData} prev={prev} setStep={setStep} />
          )}
        </div>
      </div>
    </div>
  );
}
